npm-ping(1) -- Ping npm registry
================================

## SYNOPSIS

    npm ping [--registry <registry>]

## DESCRIPTION

Ping the configured or given npm registry and verify authentication.

## SEE ALSO

* npm-config(1)
* npm-config(7)
* npmrc(5)
