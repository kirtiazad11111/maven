npm-update(3) -- Update a package
=================================

## SYNOPSIS

    npm.commands.update(packages, callback)

# DESCRIPTION

Updates a package, upgrading it to the latest version. It also installs any
missing packages.

The `packages` argument is an array of packages to update. The `callback`
parameter will be called when done or when an error occurs.

## SEE ALSO

* npm-update(1)
